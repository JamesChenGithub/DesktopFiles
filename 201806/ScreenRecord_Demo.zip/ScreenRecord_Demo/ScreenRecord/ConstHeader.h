//
//  ConstHeader.h
//  SreenRecord
//
//  Created by AlexiChen on 2018/5/29.
//  Copyright © 2018年 AlexiChen. All rights reserved.
//

#ifndef ConstHeader_h
#define ConstHeader_h


#define kSDKAPPID       
#define kAccountType

// 如果业务确定要集成：
// 请提前发送App的`Bundle Identifier`给到腾讯云，我们会为您分配与`Bundle Identifier`相对应的`appid`（屏幕录制插件中需要，必需）；
#define kRecordAppId



#endif /* ConstHeader_h */
