//
//  GuestViewController.h
//  SreenRecord
//
//  Created by AlexiChen on 2018/5/29.
//  Copyright © 2018年 AlexiChen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GuestViewController : UIViewController
@property (nonatomic, assign) int roomNum;
@end
